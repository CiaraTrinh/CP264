/*
 * myrecord_avl.c
 *
 *  Created on: Jul 12, 2023
 *      Author: trinh
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "queue_stack.h"
#include "avl.h"
#include "myrecord_avl.h"

void merge_tree(TNODE **rootp1, TNODE **rootp2) {
// use recursive or iterative algorithm to traverse tree rootp2,
// get record data of each node and insert into rootp1
	QUEUE q={0};
	TNODE *p=*rootp2;
	enqueue(&q,p);
	while (q.front){
		p = dequeue(&q);
		insert(rootp1, p->data.name, p->data.score);
		if(p->left)
			enqueue(&q, p->left);
		if(p->right)
			enqueue(&q, p->right);
	}
	clean_queue(&q);
}

void merge_data(TREE *t1, TREE *t2) {
// call the merge_tree function to merge t2->root into t1->root
// update the simple stats of the merged data set using the stats of t1 and t2.
	merge_tree(&t1->root,&t2->root);
	int count1=t1->count;
	float mean1=t1->mean;
	float stddev1=t1->stddev;
	int count2=t2->count;
	float mean2=t2->mean;
	float stddev2=t2->stddev;

	float count=count1 + count2;
	float mean=(mean1*count1 + mean2*count2)/count;
	float stddev=sqrt((1/count)*(stddev1*stddev1*count1+mean1*mean1*count1+stddev2*stddev2*count2+mean2*mean2*count2)-mean*mean);

	t1->count=count;
	t1->mean=mean;
	t1->stddev=stddev;
}

void add_data(TREE *tree, char *name, float score) {
// copy from A7
	if(search(tree->root,name)==NULL){
			insert(&(tree->root),name,score);
			int count=tree->count;
			tree->count=count+1;
			float mean=tree->mean;
			//mean=(1/(n+1)*(n*mean+x[n])
			tree->mean=((float)1/((float)count+(float)1))*((float)count*(float)mean+score);
			float stddev=tree->stddev;
			//stddev=sqrt(1/(n+1)*(n*((stddev*stddev)+(mean*mean))+((x*x)[n]))-(tree->mean*tree->mean))
			tree->stddev=sqrt(((float)1/((float)count+(float)1))*((float)count*(stddev*stddev+mean*mean)+(score*score))-(tree->mean*tree->mean));
		}
}

void remove_data(TREE *tree, char *name) {
// copy from A7
	TNODE *p=search(tree->root,name);
	if (p!=NULL){
		float score=p->data.score;
		delete(&(tree->root),name);
		int count=tree->count;
		tree->count=count-1;
		float mean=tree->mean;
		tree->mean=((float)1/(float)(tree->count))*((float)count*mean-score);
		float stddev=tree->stddev;
		tree->stddev=sqrt(((float)1/(float)(tree->count))*((float)count*(stddev*stddev+mean*mean)-(score*score))-(tree->mean*tree->mean));
	}
}
