/*
 * myrecord_avl.h
 *
 *  Created on: Jul 12, 2023
 *      Author: trinh
 */

#ifndef MYRECORD_AVL_H_
#define MYRECORD_AVL_H_

#include "avl.h"

typedef struct tree {
    TNODE *root;
    float count;
    float mean;
    float stddev;
} TREE;

/* merge tree rootp2 into tree rootp1 */
void merge_tree(TNODE **rootp1, TNODE **rootp2);

/* merge data tree t2 to data tree t1 */
void merge_data(TREE *t1, TREE *t2);

// the following are adapted/modified from A7
void add_data(TREE *tree, char *name, float score);
void remove_data(TREE *tree, char *name);

#endif /* MYRECORD_AVL_H_ */
