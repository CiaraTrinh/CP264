/*
 * dllist.c
 *
 *  Created on: Jun 11, 2023
 *      Author: trinh
 */

#include <stdio.h>
#include <stdlib.h>
#include "dllist.h"

NODE *new_node(char data) {
// your implementation
	NODE *n=(NODE*)malloc(sizeof(NODE));
	n->data=data;
	n->next=NULL;
	n->prev=NULL;
	return n;
}

void dll_insert_start(DLL *dllp, NODE *np) {
// your implementation
	if (dllp->start == NULL) {
		np->prev = NULL;
		np->next = NULL;
		dllp->start = np;
		dllp->end = np;
	}else{	// the following linking operations to set np at start
		np->prev = NULL;// this set prev of np to NULL, as start node
		np->next = dllp->start; // set next of np to the current start
		dllp->start->prev = np; // set the prev of current start to np
		dllp->start = np; // set the start of the dll to np
	}
	dllp->length++;
}

void dll_insert_end(DLL *dllp, NODE *np) {
// your implementation
	if (dllp->end==NULL){
		np->prev=NULL;
		np->next=NULL;
		dllp->end=np;
		dllp->start=np;
	}else{
		np->prev=NULL;
		np->next=dllp->end;
		dllp->end->prev=np;
		dllp->end=np;
	}
	dllp->length++;
}

void dll_delete_start(DLL *dllp) {
// your implementation
	NODE *np=dllp->start;
	if (np==NULL){
		printf("Underflow");
	}else{
		dllp->start=dllp->start->next;
		if (dllp->start != NULL) {
			dllp->start->prev=NULL;
		}
		free(np);
		if (dllp->start==NULL){
			dllp->end=NULL;
		}
		dllp->length--;
	}
}

void dll_delete_end(DLL *dllp) {
// your implementation
	NODE *np=dllp->end;
	if (np==NULL){
		printf("Underflow");
	}else{
		dllp->end=dllp->end->next;
		if(dllp->end!=NULL){
			dllp->end->prev=NULL;
		}
		dllp->end->prev=NULL;
		free(np);
		if (dllp->end==NULL){
			dllp->start=NULL;
		}
		dllp->length--;
	}
}

void dll_clean(DLL *dllp) {
// your implementation
	NODE *temp, *np=dllp->start;
	while (np!=NULL){
		temp=np;
		np=np->next;
		free(temp);
	}
	dllp->start=NULL;
	dllp->end=NULL;
	dllp->length=0;
}
