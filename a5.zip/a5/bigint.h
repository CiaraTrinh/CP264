/*
 * bigint.h
 *
 *  Created on: Jun 11, 2023
 *      Author: trinh
 */

#ifndef BIGINT_H_
#define BIGINT_H_
#include "dllist.h"

typedef DLL BIGINT;
BIGINT bigint(char *digitstr);
BIGINT add(BIGINT oprand1, BIGINT oprand2);
BIGINT Fibonacci(int n);


#endif /* BIGINT_H_ */
