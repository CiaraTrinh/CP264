/*
 * myrecord_sllist.c
 *
 *  Created on: Jun 11, 2023
 *      Author: trinh
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "myrecord_sllist.h"


NODE *sll_search(SLL *sllp, char *name) {
// your implementation
	NODE *np=sllp->start;
	while (np!=NULL){
		if (strcmp(np->data.name, name)==0) {
			break;
		}else{
			np=np->next;
		}
	}
	return np;
}

void sll_insert(SLL *sllp, char *name, float score) {
// your implementation
	NODE* np=(NODE *)malloc(sizeof(NODE));
	strcpy(np->data.name, name);
	np->data.score=score;
	np->next=NULL;
	NODE *prev=NULL, *p=sllp->start;
	while (p!=NULL){
		if (strcmp(p->data.name, name)>=0){
			break;
		}else{
			prev=p;
			p=p->next;
		}
	}
	if (prev==NULL){
		sllp->start=np;
		np->next=p;
	}else{
		prev->next=np;
		np->next=p;
	}
// need to update the length
	sllp->length++;
}

int sll_delete(SLL *sllp, char *name) {
// your implementation
	int found=0;
	NODE *prev=NULL, *p=sllp->start;
	while (p!=NULL){
			if (strcmp(p->data.name, name)>=0){
				found=1;
				break;
				if (prev==NULL){
					sllp->start=p->next;
				}else{
					prev->next=p->next;
				}
				free(p);
				sllp->length--;
				break;
			}
// need to update the length
			prev=p;
			p=p->next;
	}
	return found;
}

void sll_clean(SLL *sllp) {
  // your implementation
	NODE *temp, *p=sllp->start;
	while (p!=NULL){
		temp=p;
		p=p->next;
		free(temp);
	}
  // need to reset the start and length
	sllp->start=0;
	sllp->length=0;
}
