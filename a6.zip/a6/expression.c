/*
 * expression.c
 *
 *  Created on: Jun 23, 2023
 *      Author: trinh
 */

#include <stdio.h>
#include <stdlib.h>
#include "common.h"
#include "queue.h"
#include "expression.h"
#include "stack.h"

/*
 * auxiliary function
*/
int get_priority(char op) {
  if (op == '/' || op == '*' || op == '%')
    return 1;
  else if (op == '+' || op == '-')
    return 0;
  else
    return -1;
}

/*
 * auxiliary function
*/
int type(char c) {
  if (c >= '0' &&  c <= '9' )
     return 0;
  else if (c == '/' || c == '*' || c == '%' || c == '+' || c == '-')
    return 1;
  else if (c == '(')
    return 2;
  else if ( c == ')')
    return 3;
  else
    return 4;
}

QUEUE infix_to_postfix(char *infixstr) {
// your implementation
	char *p=infixstr;
	QUEUE queue={0};	// result postfix expression in queue
	STACK stack={0};	// auxiliary stack
	int sign = 1, num = 0;
	while (*p){ // expression str traversal
	if ( *p=='-'&&(p==infixstr||*(p-1)=='(')){// get the sign of an operand
		sign = -1;
	}else if (*p>='0'&&*p<='9'){ // case of number character
		// use horner’s algorithm to get the operand
		num=*p-'0';
		while((*(p+1)>='0'&&*(p+1)<='9')){
			num = num*10 + *(p+1)-'0';
			p++;
		}
		enqueue(&queue, new_node(sign*num, 0));
		sign = 1;
	}
	else if(*p=='('){
		push(&stack, new_node(*p, 2));
	}
	else if(*p==')'){
		NODE *n = pop(&stack);
		while(n->type != 2){
			if(n->type == 1){
				enqueue(&queue, n);
			    }
			    n = pop(&stack);
			}
		}else if(type(*p) == 1){
	    	while(stack.top && stack.top->type==1 && get_priority(stack.top->data)>=get_priority(*p)){
	    		enqueue(&queue,pop(&stack));
	    	}
	    	push(&stack, new_node(*p, 1));
	    }
		p++;
	}
	while(stack.top){
		enqueue(&queue, pop(&stack));
	}
	return queue;
}

int evaluate_postfix(QUEUE queue) {
// your implementation
	NODE *p = queue.front;
	STACK stack = {0}; // auxilliary stack for postfix evaluation
	int type = 0;
	while (p) { // traversal the queue linked list
		type = p->type;
		if (type == 0) { // operant
			push(&stack, new_node(p->data, 0));
		}else if (type==1){ // operator
			char opr=p->data;
			NODE *bp=pop(&stack), *ap=pop(&stack);
			int b=bp->data, a=ap->data,c;
			switch(opr){
				case '+': c=a+b;
				break;
				case '%': c=a%b;
				break;
				case '*': c=a*b;
				break;
				case '/': c=a/b;
				break;
				case '-': c=a-b;
				break;
			}
			push(&stack, new_node(c,0));
			free(bp);
			free(ap);
		}
		p = p->next;
	}
	int result = stack.top->data;
	stack_clean(&stack);
	return result;
}



int evaluate_infix(char *infixstr) {
// your implementation
	QUEUE postfix_queue=infix_to_postfix(infixstr);
	int value=evaluate_postfix(postfix_queue);
	return value;
}
