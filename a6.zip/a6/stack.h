/*
 * stack.h
 *
 *  Created on: Jun 23, 2023
 *      Author: trinh
 */

#ifndef STACK_H_
#define STACK_H_

#include "common.h"

typedef struct stack {
  int height;
  NODE *top;
} STACK;

void push(STACK *sp, NODE *np);
NODE *pop(STACK *sp);
void stack_clean(STACK *sp);

#endif /* STACK_H_ */
