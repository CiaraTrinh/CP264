/*
 * myrecord.c
 *
 *  Created on: Jun 6, 2023
 *      Author: trinh
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "myrecord.h"
#include "mysort.h"

#define MAX_LINE 100

GRADE grade(float score){
  GRADE r = {"F", 0};
  int p = (int) round(score);
  r.percentage = p;
  char g[14][5] = {"A+", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D+", "D", "D-", "F"};
  int b[] = {100, 90, 85, 80, 77, 73, 70, 67, 63, 60, 57, 53, 50, 0};
  int i=0, n = sizeof(b)/sizeof(float);
  for (i=0; i<n; i++) {
	  if (p >= b[i+1]) break;
  }
  strcpy(r.letter_grade, g[i]);
  return r;
}

STATS process_data(RECORD *dataset, int n) {
// your implementation
	STATS stats={0};
	stats.count=n;

	float stddev=0, mean=0, median=0;
	//compute mean
	for (int i=0; i<n;i++){
		mean+=dataset[i].score;
	}
	mean/=n;
	//compute stddev
	for (int i=0;i<n;i++){
		stddev+=(dataset[i].score-mean)*(dataset[i].score-mean);
	}
	stddev=sqrt(stddev/n);
	//set median
	float score[n];
	for (int i=0;i<n;i++){
		score[i]=dataset[i].score;
	}
	if(n%2){
		median=score[n/2];
	}else{
		median=(score[(n/2)-1] + score[n/2])/2;
	}

	stats.mean=mean;
	stats.stddev=stddev;
	stats.median=median;
	return stats;
}

int import_data(char *infilename, RECORD *dataset) {
// your implementation
	char delimiters[] = " ,\n\r";
	char line[MAX_LINE];
	int i = 0;
	FILE *fp = fopen(infilename, "r");
	char *token = NULL;
	while (fgets (line, sizeof(line), fp) != NULL ){
		token = (char *) strtok(line, delimiters);
		strcpy(dataset[i].name, token);
		token = (char*) strtok(NULL, delimiters);
		sscanf(token, "%f", &dataset[i].score);
		i++;
	}
	fclose(fp);
	return i;
}

int report_data(char *outfilename, RECORD dataset[], STATS stats) {
// your implementation
	int n = stats.count;
	FILE *fp = fopen(outfilename, "w");

	fprintf(fp, "Name,Score\n");
	for (int i=0;i<n;i++){
		// write to file
		fprintf(fp, "%s,%.2f\n", dataset[i].name, dataset[i].score);
	}
	fclose(fp);
	return 1;
}
