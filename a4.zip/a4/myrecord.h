/*
 * myrecord.h
 *
 *  Created on: Jun 6, 2023
 *      Author: trinh
 */

#ifndef MYRECORD_H_
#define MYRECORD_H_

typedef struct {
  char name[40];
  float score;
} RECORD;

typedef struct {
  float count;
  float mean;
  float stddev;
  float median;
} STATS;

typedef struct {
  char letter_grade[5];
  int percentage;
} GRADE;

GRADE grade(float score);
int import_data(char *infilename, RECORD *dataset);
STATS process_data(RECORD *dataset, int n);
int report_data(char *outfilename,  RECORD *dataset, STATS stats);

#endif /* MYRECORD_H_ */
