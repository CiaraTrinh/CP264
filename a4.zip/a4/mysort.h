/*
 * mysort.h
 *
 *  Created on: Jun 6, 2023
 *      Author: trinh
 */

#ifndef MYSORT_H_
#define MYSORT_H_

void select_sort(float *a[], int left, int right);
void quick_sort(float *a[], int left, int right);

#endif /* MYSORT_H_ */
