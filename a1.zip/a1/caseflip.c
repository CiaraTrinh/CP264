/*
 * caseflip.c
 *
 *  Created on: May 11, 2023
 *      Author: trinh
 */

#include <stdio.h>

int main() {
	setbuf(stdout, NULL);
	char c = 0, temp;
	do{
		printf("Please enter a character\n");
		scanf("%c", &c);
		// flush the input buffer
		if (c!='\n'){
			while (getc(stdin)!='\n');
		}
		do{
			scanf("%c", &temp);
			if (temp == '\n') break;
		}while (1);
		if (c>='a' && c<='z'){
			printf("%c:%d,%c,%d\n",c,c,c-32,c-32);
		}else if (c>='A' && c<='Z'){
			printf("%c:%d,%c,%d\n",c,c,c+32,c+32);
		}else if(c=='!'){
			printf("%c:Quit\n", c);
			break;
		}else if(c>='0' && c<='9'){
			int x=c-'0';
			printf("%c:%d,%d,%d\n",c,c,x,x*x);
		}else{
			printf("%c:Invalid\n",c);
		}
	}while (1);

	printf("%c:Quit\n", c);
	return 0;
}
