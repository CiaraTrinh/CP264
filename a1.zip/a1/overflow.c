/*
 * overflow.c
 *
 *  Created on: May 11, 2023
 *      Author: trinh
 */

#include <stdio.h>
#include <math.h>

int main(int argc, char *args[]){
	int i, n=0, sum=0, b=1, p=1, is_overflow=0;
	if (argc>2){
		sscanf(args[1],"%d",&b);
		sscanf(args[2],"%d",&n);
		if (b >=1 && n >= 0){
			//code here
			sum=1;
			for (i=1;i<=n;i++){
				p=pow(b,i);
				sum+=p;
				if(p*b<p || sum+p*b<sum){
					is_overflow=1;
					break;
				}
			}
			if(is_overflow){
				printf("powersum(%d %d):overflow\n",b,n);
			}else{
				printf("powersum(%d %d): %d\n",b,n,sum);
			}
		}else{
			printf("%s:invalid argument\n");
		}
	}else{
		printf("arguments:b>0 n>0\n");
	}
	return 0;
}
