/*
 * quadratic.c
 *
 *  Created on: May 16, 2023
 *      Author: trinh
 */

#include <stdio.h>
#include <math.h>

#define EPSILON 1e-6

int main(int argc, char* argv[])
{
	float a, b, c, d, x1, x2;

	if (argc < 2) {
		printf("argument input:missing\n");
	}else {
		int n = sscanf(argv[1], "%f,%f,%f", &a, &b, &c);
		if (n != 3) {
			printf("input:invalid\n");
		} else {
			printf("(%.2f)x^2+(%.2f)x+(%.2f)=0: ", a, b, c);
			if (fabs(a) < EPSILON) {
				printf("not a quadratic equation\n");
			}else{

				// write your solution logic for cases 2-4
				d=b*b-4*a*c;
				if (fabs(d)<EPSILON){
					x1=-b/(2*a);
					printf("%.2f, %.2f\n",x1,x1);
				}else if (d>EPSILON){
					d=sqrt(d);
					x1=(-b+d)/(2*a);
					x2=(-b-d)/(2*a);
					printf("%.2f, %.2f\n", x1,x2);
				}else{
					x1=-b/(2*a);
					x2=sqrt(-d)/(2*a);
					printf("%.2f+%.2fi, %.2f-%.2fi\n", x1,x2,x1,x2);
				}
    		}
    	}
	}
	return 0;
}
