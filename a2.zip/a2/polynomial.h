/*
 * polynomial.h
 *
 *  Created on: May 23, 2023
 *      Author: trinh
 */

#ifndef POLYNOMIAL_H_
#define POLYNOMIAL_H_

float horner(float *p, int n, float x);
float bisection(float *p, int n, float a, float b);

#endif /* POLYNOMIAL_H_ */
