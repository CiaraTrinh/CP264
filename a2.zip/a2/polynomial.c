/*
 * polynomial.c
 *
 *  Created on: May 23, 2023
 *      Author: trinh
 */

#include <stdio.h>
#include <math.h>
#include "polynomial.h"

#define EPSILON 1e-6

float horner(float *p, int n, float x){
// your implementation
	float r=0;
	for (int i=0;i<n;i++){
		r=r*x+p[i];
	}
	return r;
}

float bisection(float *p, int n, float a, float b){
// your implementation
	float c;
	c=(a+b)/2;
	while(fabs(horner(p,n,c))>=EPSILON){
		if(horner(p,n,c)*horner(p,n,a)>0){
			a = c;
	    }else{
	        b = c;
	    }
	    c = (a+b)/2;
	}
	return c;
}
