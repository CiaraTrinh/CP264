/*
 * matrix.c
 *
 *  Created on: May 23, 2023
 *      Author: trinh
 */

#include <stdio.h>
#include <math.h>
#include "matrix.h"

float sum(float *v, int n) {
// your implementation
	float s=0;
	for (int i=0; i<n;i++)
		s+=v[i];
	return s;
}

float norm(float *v, int n) {
// your implementation
	float s=0;
	for (int i=0;i<n;++i){
		s+=v[i]*v[i];
	}
	return sqrt(s);
}

float dot_product(float *v1, float *v2, int n) {
// your implementation
	float s=0;
	for (int i=0;i<n;++i){
		s+=v1[i]*v2[i];
	}
	return s;
}

void transpose_matrix(float *m1, float *m2, int n) {
// your implementation
	int i,j;
	for (i=0;i<n;i++){
		for (j=0;j<n;j++){
			m2[j*n+i]=m1[i*n+j];
		}
	}
}

void matrix_multiply_vector(float *m, float *vin, float *vout, int n) {
// your implementation
	float s=0;
	int i,k;
	for (i=0;i<n;i++){
		s=0;
		for (k=0;k<n;k++){
			s+=*(m+i*n+k)**(vin+k);
		}
		*(vout+i)=s;
	}
}

void multiply_matrix(float *m1, float *m2, float *m3, int n) {
// your implementation
	float s;
	int i,j,k;
	for (i=0;i<n;i++){
		for (j=0;j<4;j++){
			s=0;
			for (k=0;k<n;k++){
				s+=m1[i*n+k]*m2[k*n+j];
			}
			*(m3+i*n+j)=s;
		}
	}
}
