/*
 * matrix.h
 *
 *  Created on: May 23, 2023
 *      Author: trinh
 */

#ifndef MATRIX_H_
#define MATRIX_H_

float sum(float *v, int n);
float norm(float *v, int n);
float dot_product(float *v1, float *v2, int n);
void transpose_matrix(float *m1, float *m2, int n);
void multiply_matrix(float *m1, float *m2, float *m3, int n);
void matrix_multiply_vector(float *m, float *v1, float *v2, int n);

#endif /* MATRIX_H_ */
