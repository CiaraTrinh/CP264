JobID: cp264oc-a2-lab2
Name: Trinh Thi Que Chi
ID: 000006750

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description

Lab2

T1 C Debugging
T1.1 [1/2/*] Debug under command line

factorial
Enter the number: 3
The factorial of 3 is 6

gcc -g factorial.c -o factorial

gdb factorial
GNU gdb (GDB) 7.6.1
Copyright (C) 2013 Free Software Foundation, Inc.
License GPLv3+: GNU GPL version 3 or later <http://gnu.org/licenses/gpl.html>
This is free software: you are free to change and redistribute it.
There is NO WARRANTY, to the extent permitted by law.  Type "show copying"
and "show warranty" for details.
This GDB was configured as "mingw32".
For bug reporting instructions, please see:
<http://www.gnu.org/software/gdb/bugs/>...
Reading symbols from C:\Users\trinh\Downloads\Java\Lab2\src\factorial.exe...done.
(gdb) break 1
Breakpoint 1 at 0x40146e: file factorial.c, line 1.
(gdb) run
Starting program: C:\Users\trinh\Downloads\Java\Lab2\src/factorial.exe
[New Thread 27340.0x652c]
[New Thread 27340.0x473c]

Breakpoint 1, main () at factorial.c:11
11        int i, num=3, j=1;
(gdb) p j
$1 = 0
(gdb) c
Continuing.
Enter the number: 3
The factorial of 3 is 6
[Inferior 1 (process 27340) exited normally]
(gdb) q

T1.2 [1/2/*] Debug under Eclipse

GNU gdb (GDB) 7.6.1
Copyright (C) 2013 Free Software Foundation, Inc.
License GPLv3+: GNU GPL version 3 or later <http://gnu.org/licenses/gpl.html>
This is free software: you are free to change and redistribute it.
There is NO WARRANTY, to the extent permitted by law.  Type "show copying"
and "show warranty" for details.
This GDB was configured as "mingw32".
For bug reporting instructions, please see:
<http://www.gnu.org/software/gdb/bugs/>.
[New Thread 33380.0x9328]
[New Thread 33380.0x2f18]

T2 Pointers
T2.1 [1/2/*] Test on pointers

pointer.c
Value of x: 10
Address of x: 6422300
Value of pointer ptr: 6422300
Address of pointer ptr: 6422296
ptr pointing to value: 10

pointer2.c
Value of x: 10
Address of x in Hex: 0061FF1C
Address of x in decimal: 6422300
Value of pointer variable ptr: 0061FF1C (address in Hex)
Address of pointer variable ptr (&ptr): 6422296
The value pointed by ptr (*ptr): 10
&pptr: 6422292
*pptr: 6422300
**pptr: 10,  *(*pptr): 10

address1.c
Value of a: 1, address: 4210692
Value of b: 2, address: 4210696
Value of c: 3, address: 4210700
Value of x: 10, address: 6422292
Value of y: 1.100000, address: 6422280
Value in pointer variable p, 6422292, sizeof p: 4, address of p:  6422276 
Value in py: 6422280, sizeof py: 4
void pointer address: 6422292, casted value: 10


T3 Arrays
T3.1 [1/2/*] Test on arrays

Global array
list[0]: 1, address: 4223088
list[1]: 2, address: 4223092
list[2]: 3, address: 4223096
list[3]: 4, address: 4223100
list[4]: 5, address: 4223104
Local array
a[0]: 5, address: 6422280
a[1]: 4, address: 6422284
a[2]: 3, address: 6422288
a[3]: 2, address: 6422292
a[4]: 1, address: 6422296

list[0]: 1, address: 6422268
list[1]: 2, address: 6422272
list[2]: 3, address: 6422276
list[3]: 4, address: 6422280
list[4]: 5, address: 6422284
c[0]: a, address: 6422263
c[1]: b, address: 6422264
c[2]: c, address: 6422265
c[3]: d, address: 6422266
c[4]: e, address: 6422267
d[0]: 1.000000, address: 6422216
d[1]: 2.000000, address: 6422224
d[2]: 3.000000, address: 6422232
d[3]: 4.000000, address: 6422240
d[4]: 5.000000, address: 6422248

Before increase
x[0]: 0
x[1]: 1
x[2]: 2
After increase
x[0]: 1
x[1]: 2
x[2]: 3

T4 2D Arrays
T4.1 [1/2/*] Test on 2D arrays


  1
  1  1
  1  2  1
  1  3  3  1
  1  4  6  4  1

  6421992  6421996  6422000  6422004  6422008
  6422012  6422016  6422020  6422024  6422028
  6422032  6422036  6422040  6422044  6422048
  6422052  6422056  6422060  6422064  6422068
  6422072  6422076  6422080  6422084  6422088

  6421992  6421996  6422000  6422004  6422008
  6422012  6422016  6422020  6422024  6422028
  6422032  6422036  6422040  6422044  6422048
  6422052  6422056  6422060  6422064  6422068
  6422072  6422076  6422080  6422084  6422088

  6421992  6422012  6422032  6422052  6422072

  6421992  6422012  6422032  6422052  6422072


6422132
   1  6422132   2  6422136   3  6422140   4  6422144
   5  6422148   6  6422152   7  6422156   8  6422160
   9  6422164  10  6422168  11  6422172  12  6422176
6422180
  13  6422180  14  6422184  15  6422188  16  6422192
   0  6422196   0  6422200   0  6422204   0  6422208
   0  6422212   0  6422216   0  6422220   0  6422224
   
======arr[2][3]======
display()
1 2 3 
4 5 6 
display1()
1 2 3 
4 5 6 
*(*(a + 0) + 0):1
*(*a + 2):3
*(a[0] + 2):3
display2()
1 2 3 
4 5 6 
======arr[3][3]======

1 2 3 
4 5 6 
7 8 9 

======transpose(3, mat)======
1 4 7 
2 5 8 
3 6 9 

======transpose_pointer(3, &mat[0][0])======
1 2 3 
4 5 6 
7 8 9    

A2

Q1 Computing Fibonacci numbers
Q1.1 [2/2/*] iterative_fibonacci()                   
Q1.2 [2/2/*] recursive_fibonacci()                   
Q1.3 [2/2/*] dpbu_fibonacci()                        
Q1.4 [2/2/*] dptd_fibonacci() 

fibonacci 1
iterative_fibonacci(1):1
recursive_fibonacci(1):1
dpbu_fibonacci(1):1
dptd_fibonacci(1):1

fibonacci 10
iterative_fibonacci(10):55
recursive_fibonacci(10):55
dpbu_fibonacci(10):55
dptd_fibonacci(10):55

fibonacci 20
iterative_fibonacci(20):6765
recursive_fibonacci(20):6765
dpbu_fibonacci(20):6765
dptd_fibonacci(20):6765

fibonacci 40
iterative_fibonacci(40):102334155
recursive_fibonacci(40):102334155
dpbu_fibonacci(40):102334155
dptd_fibonacci(40):102334155

fibonacci_time

**Function runtime measurement**
time_span(iterative_fibonacci(40) for 50000 times):4.0 (ms)
time_span(recursive_fibonacci(40) for 5 times):2606.0 (ms)
time_span(iterative_fibonacci(40) for 50000 times):8.0 (ms)
time_span(iterative_fibonacci(40) for 5000 times):16.0 (ms)


**Comparisons**
time_span(recursive_fibonacci(40))/time_span(iterative_fibonacci(40)):6515000.0
time_span(dpbu_fibonacci(40))/time_span(iterative_fibonacci(40)):2.0
time_span(dptd_fibonacci(40))/time_span(iterative_fibonacci(40)):40.0
time_span(recursive_fibonacci(40))/time_span(dptd_fibonacci(40)):162875.0                       


Q2 Array & polynomial
Q2.1 [5/5/*] horner()                                
Q2.2 [5/5/*] bisection()  

P(0.00)=1.00*0.00^3+2.00*0.00^2+3.00*0.00^1+4.00*0.00^0=4.00
P(1.00)=1.00*1.00^3+2.00*1.00^2+3.00*1.00^1+4.00*1.00^0=10.00
P(10.00)=1.00*10.00^3+2.00*10.00^2+3.00*10.00^1+4.00*10.00^0=1234.00
P(-2.00)=-2.00
P(2.00)=26.00
root=-1.65
P(-1.65)=0.00                           

Q3 Vector and Matrix
Q3.1 [2/2/*] sum()                                   
Q3.2 [2/2/*] norm()                                  
Q3.3 [2/2/*] dot_product()                           
Q3.4 [2/2/*] transpose_matrix()                      
Q3.5 [2/2/*] multiply_matrix()                       
Q3.6 [2/2/*] matrix_multiply_vector()  

v1:   1.0   1.0   1.0

sum(v1):3.0

norm(v1):1.7

dot_product(v1 v1):3.0

v2:   1.0   2.0   3.0

sum(v2):6.0

norm(v2):3.7

doc_product(v2 v2):14.0

doc_product(v1 v2):6.0

m1:
   8.0   1.0   6.0
   3.0   5.0   7.0
   4.0   9.0   2.0
sum(m1[0]):15.0

m2=m1':
   8.0   3.0   4.0
   1.0   5.0   9.0
   6.0   7.0   2.0
sum(m2[0]):15.0

m3=m1*m2':
 101.0  71.0  53.0
  71.0  83.0  71.0
  53.0  71.0 101.0

v2=m1*v1':  15.0  15.0  15.0              

Total: [40/40/*]


