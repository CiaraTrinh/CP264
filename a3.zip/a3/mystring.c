/*
 * mystring.c
 *
 *  Created on: May 30, 2023
 *      Author: trinh
 */

#include <stdio.h>
#include "mystring.h"

int str_len(char *s) {
// your implementation
	if (s==NULL) return -1;
	int counter = 0;
	char *p = s;
	while (*p) {
		if(*p!='\0')		//pattern
			counter++;
		p++;
	}
	return counter;
}

int str_wc(char *s) {
// your implementation
	if (s==NULL) return -1;
	int counter=0;
	char *p=s;
	while(*p){
		if(*p!=' '&&(p==s||*(p-1)==' '))
			counter++;
		p++;
	}
	return counter;
}

void str_lower(char *s) {
// your implementation
	if (s==NULL){
		char *p=s;
		while (*s){
			if(*p>='A'&&*p<='Z')
				*p+=32;
			p++;
		};
	}
}

void str_trim(char *s) {
// your implementation
	if (s==NULL) return;
	char *p=s, *dp=s;
	while(*p){
		if(*p!=' '||(p>s && *(p-1)!=' ')){
			*dp=*p;
			dp++;
		}
		p++;
	}
	if (*(p - 1)==' ')
		*(dp - 1)='\0';
	else
		*dp = '\0';
}
