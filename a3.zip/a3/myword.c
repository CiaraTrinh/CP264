/*
 * myword.c
 *
 *  Created on: May 30, 2023
 *      Author: trinh
 */

#include <stdio.h>
#include <string.h>
#include "myword.h"
#include "mystring.h"

void stopword_dictionay(char *filename, char *stopwords[]){
// your implementation
	FILE *fp = fopen(filename,"r");
	char line[1000];
	char delimiters[] = " .,\n\t\r";
	char *word_token;
	int i;
	while (fgets(line,1000,fp)!=NULL){
		word_token=(char*)strtok(line, delimiters);
		while(word_token != NULL) {
			i=(int)(*word_token - 'a');
			strcat(stopwords[i],word_token);
			strcat(stopwords[i],",");
			word_token=(char*) strtok(NULL, delimiters);
		}
	}
	fclose(fp);
}

int is_stopword(char *stopwords[], char *word){
// your implementation
	if(word==NULL||*word=='\0')
		return 0;
	else{
		char temp[20]={0};
		strcat(temp, ",");
		strcat(temp, word);
		strcat(temp, ",");

		if (strstr(stopwords[*word - 'a'], temp)) {
			return 1;
		}else{
			return 0;
		}
	}
}

int process_word(char *filename, WORDSUMMARY *words, char *stopwords[]){
// your implementation
	FILE *fp = fopen(filename,"r");
	char delimiters[] = " .,\n\t\r";
	char *word_token;
	char line[MAX_LINE_LEN];
	while (fgets(line, MAX_LINE_LEN, fp) != NULL) { // traversing all lines
		words->line_count++;
		str_lower(line);
		str_trim(line);
		word_token=(char*)strtok(line, delimiters);
		while(word_token != NULL){
			if(is_stopword(stopwords,word_token)==0){
				//action: insert word_token
				words->word_count++;
				int j=0;
				while(j<words->word_count && strcmp(word_token, words->word_array[j].word)!=0)
					j++;
				if(j<words->word_count){
					words->word_array[j].frequency++;
				}else{
					strcpy(words->word_array[j].word, word_token);
					words->word_array[j].frequency=1;
					words->word_count++;
				}
			}
			word_token=(char*)strtok(NULL,delimiters);
		}
	}
	fclose(fp);
	return 0;
}
