JobID: cp264oc-a9-lab9
Name: Trinh Thi Que Chi
ID: 000006750

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description

Lab9

T1 Hash tables
T1.1 [5/5/*] Read and test hash tables

T2 Heaps
T2.1 [5/5/*] Read and test Heaps

A9

Q1 Chained hash table
Q1.1 [3/3/*] new_node(), new_hashtable()             
Q1.2 [2/3/*] search()                                
Q1.3 [2/3/*] insert()                                
Q1.4 [2/3/*] delete()                                

Q2 Symbolic expression evaluation
Q2.1 [2/6/*] infix_to_postfix_symbol()               

Q3 Binary heap
Q3.1 [1/3/*] new_heap(),find_index_data()            
Q3.2 [1/3/*] insert()                                
Q3.3 [1/3/*] extract_min()                           
Q3.4 [1/3/*] change_key()                            

Total: [25/40/*]


