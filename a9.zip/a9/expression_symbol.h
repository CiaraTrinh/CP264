/*
 * expression_symbol.h
 *
 *  Created on: Jul 19, 2023
 *      Author: trinh
 */

#ifndef EXPRESSION_SYMBOL_H_
#define EXPRESSION_SYMBOL_H_

#include "common_queue_stack.h"
#include "hash.h"

QUEUE infix_to_postfix_symbol(char *infixstr, HASHTABLE *ht);
int evaluate_infix_symbol(char *infixstr, HASHTABLE *ht);
int evaluate_postfix(QUEUE queue);


#endif /* EXPRESSION_SYMBOL_H_ */
