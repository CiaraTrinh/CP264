/*
 * hash.c
 *
 *  Created on: Jul 19, 2023
 *      Author: trinh
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hash.h"

extern int htsize;

int hash(char* word) {
  unsigned int hash = 0, i;
  for (i = 0; word[i] != '\0'; i++) {
    hash = 31 * hash + word[i];
  }
  return hash % htsize;
}

HSNODE *new_hashnode(char *key, int value) {
// your implementation
	HSNODE *hn=(HSNODE*)malloc(sizeof(HSNODE));
	hn->value=value;
	strcpy(hn->key,key);
	hn->next=NULL;
	return hn;
}

HASHTABLE *new_hashtable(int size) {
// your implementation
	HASHTABLE *ht=(HASHTABLE*)malloc(sizeof(HASHTABLE));
	ht->hna=(HSNODE**)malloc(sizeof(HSNODE**)*size);
	int i;
	for (i=0; i<size; i++) *(ht->hna+i) = NULL; //initialize to NULL
	ht->size = size;
	ht->count = 0;
	return ht;
}

HSNODE *search(HASHTABLE *ht, char *key) {
// your implementation
	int i = hash(key); // compute the hash index of name
	HSNODE *p = ht->hna[i]; // get the linked list of the hash value
	// search the linked list, if name is matched, return the node
	while (p != NULL) {
		if (strcmp(p->key, key) == 0) {
			return p;
	    }
	    p = p->next;
	}
	return NULL;
}

int insert(HASHTABLE *ht, HSNODE *np) {
// your implementation
	int i = hash(np->key);
	HSNODE *p = ht->hna[i], *pp = NULL;
	if (p == NULL) {
		ht->hna[i] = np;
	}else{
		while (p && strcmp(np->key, p->key) > 0) {
			pp=p;
			p=p->next;
		}
		if (p && strcmp(np->key, p->key) == 0) {
			p->value = np->value;
			free(np);
			return 0;
		}
		if (pp == NULL)
			ht->hna[i] = np;
		else{
			pp->next = np;
			np->next = p;
		}
	}
	ht->count++;
	return 1;
}

int delete(HASHTABLE *ht, char *key) {
// your implementation
	int i=hash(key);
	HSNODE *p = ht->hna[i], *pp = NULL;
	while (p != NULL && strcmp(p->key, key) != 0) {
		pp = p;
		p = p->next;
	}
	if (p == NULL) {
		return 0;
	}
	if (pp == NULL) {
		ht->hna[i] = p->next;
	}else{
		pp->next = p->next;
	}
	free(p);
	return 1;
}


void clean_hash(HASHTABLE **htp) {
  if (*htp == NULL) return;
  HASHTABLE *ht = *htp;
  HSNODE *sp = ht->hna[0], *p, *temp;
  int i;
  for (i = 0; i < ht->size; i++) {
    p = ht->hna[i];
    while (p) {
      temp = p;
      p = p->next;
      free(temp);
    }
    ht->hna[i] = NULL;
  }
  free(ht->hna);
  ht->hna = NULL;
  *htp = NULL;
}
