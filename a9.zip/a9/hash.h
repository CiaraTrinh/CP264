/*
 * hash.h
 *
 *  Created on: Jul 19, 2023
 *      Author: trinh
 */

#ifndef HASH_H_
#define HASH_H_

typedef struct hashnode {
  char key[10];
  int value;
  struct hashnode *next;
} HSNODE;

typedef struct hashtable {
  HSNODE **hna;
  int size;
  int count;
} HASHTABLE;

int hash(char *key);
HSNODE *new_hashnode(char *key, int vale);
HASHTABLE *new_hashtable(int size);
HSNODE *search(HASHTABLE *ht, char *key);
int insert(HASHTABLE *ht, HSNODE *np);
int delete(HASHTABLE *ht, char *key);
void clean_hash(HASHTABLE **ht);

#endif /* HASH_H_ */
