/*
 * bst.c
 *
 *  Created on: Jul 6, 2023
 *      Author: trinh
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "bst.h"


TNODE *search(TNODE *root, char *name) {
// your implementation
	while (root!=NULL){
		if (strcmp(name,root->data.name)==0){
			return root;
		}else if(strcmp(name,root->data.name)<0){
			root=root->left;
		}else{
			root=root->right;
		}
	}
	return NULL;
}

void insert(TNODE **rootp, char *name, float score) {
// your implementation
	TNODE* np = (TNODE*)malloc(sizeof(TNODE));
	if (*rootp == NULL) {
		np->data.score = score;
		strcpy(np->data.name, name);
		np->left = NULL;
		np->right = NULL;
		(*rootp) = np;
	}else{
		int flag = strcmp(name, (*rootp)->data.name);
		if (flag < 0){
			insert(&(*rootp)->left, name, score);
		}else if (flag > 0) {
			insert(&(*rootp)->right, name, score);
		}
	}
}

void delete(TNODE **rootp, char *name) {
// your implementation
	TNODE *root = *rootp, *tnp;
	int flag = strcmp(name, root->data.name);
	if (root==NULL) {
		return;
	}if (flag == 0) {
		if (root->left == NULL && root->right == NULL) {
			free(root);
			*rootp = NULL;
		}else if (root->left != NULL && root->right == NULL) {
			tnp = root->left;
			*rootp = tnp;
			free(root);
		}else if (root->left == NULL && root->right != NULL) {
			tnp = root->right;
			*rootp = tnp;
			free(root);
		} else if (root->left != NULL && root->right != NULL) {
			tnp = root->left;
			tnp = root->right;
			*rootp = tnp;
			free(root);
		}
	}else{
		if (flag < 0){
			return delete(&root->left, name);
		}else{
			return delete(&root->right, name);
		}
	}
}


TNODE *new_node(char *name, float score) {
	TNODE *np = (TNODE *) malloc(sizeof(TNODE));
	if (np) {
		strcpy(np->data.name, name);
		np->data.score = score;
		np->left = NULL;
		np->right = NULL;
	}
	return np;
}


TNODE *extract_smallest_node(TNODE **rootp) {
  TNODE *p = *rootp, *parent = NULL;
  if (p) {
    while (p->left) {
      parent = p;
      p = p->left;
    }

    if (parent == NULL)
      *rootp = p->right;
    else
      parent->left = p->right;

    p->left = NULL;
    p->right = NULL;
  }

  return p;
}

void clean_tree(TNODE **rootp) {
  TNODE *root = *rootp;
  if (root) {
    if (root->left)
      clean_tree(&root->left);
    if (root->right)
      clean_tree(&root->right);
    free(root);
  }
  *rootp = NULL;
}
