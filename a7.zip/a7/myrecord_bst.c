/*
 * myrecord_bst.c
 *
 *  Created on: Jul 6, 2023
 *      Author: trinh
 */

#include <stdio.h>
#include <math.h>
#include "queue_stack.h"
#include "bst.h"
#include "myrecord_bst.h"

void add_data(TREE *tree, char *name, float score) {
// your implementation
	if(search(tree->root,name)==NULL){
		insert(&(tree->root),name,score);
		int count=tree->count;
		tree->count=count+1;
		float mean=tree->mean;
		//mean=(1/(n+1)*(n*mean+x[n])
		tree->mean=((float)1/((float)count+(float)1))*((float)count*(float)mean+score);
		float stddev=tree->stddev;
		//stddev=sqrt(1/(n+1)*(n*((stddev*stddev)+(mean*mean))+((x*x)[n]))-(tree->mean*tree->mean))
		tree->stddev=sqrt(((float)1/((float)count+(float)1))*((float)count*(stddev*stddev+mean*mean)+(score*score))-(tree->mean*tree->mean));
	}
}

void remove_data(TREE *tree, char *name) {
// your implementation
	TNODE *p=search(tree->root,name);
	if (p!=NULL){
		float score=p->data.score;
		delete(&(tree->root),name);
		int count=tree->count;
		tree->count=count-1;
		float mean=tree->mean;
		tree->mean=((float)1/(float)(tree->count))*((float)count*mean-score);
		float stddev=tree->stddev;
		tree->stddev=sqrt(((float)1/(float)(tree->count))*((float)count*(stddev*stddev+mean*mean)-(score*score))-(tree->mean*tree->mean));
	}
}
